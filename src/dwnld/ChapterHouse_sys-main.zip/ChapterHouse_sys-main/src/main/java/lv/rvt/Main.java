package lv.rvt;

import lv.rvt.mainFunctions.Structure;

public class Main {
    public static void main( String[] args ) throws Throwable {

        Structure.start();        
    }
}

